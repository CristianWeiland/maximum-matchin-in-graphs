import subprocess
import random

def xshift(r):
    r2 = []
    r3 = []
    
    for j in range(len(r)):
        r2.append(r[j])
    k = len(r)
    for j in range(k):
        l = random.randint(0, len(r2)-1)
        v = r2[l]
        r2.remove(v)
        r3.append(v)

    return r3

mix = [[0, 0], [8, 8], [4, 16], [4, 32], [4, 64], [2, 128], [2, 256], [2,512]]
for i in range(1, len(mix)):
    for j in range(mix[i][0]):
        np1 = random.randint(mix[i-1][1], mix[i][1])
        np2 = random.randint(mix[i-1][1], mix[i][1])
        name = str(np1)+"_"+str(np2)
        f = open(name+".dot", "w")
        p1 = []
        p2 = []
        f.write("strict graph grafo_%s {\n" % name)
        for j in range(np1):
            p1.append("x"+str(j))
        for j in range(np2):
            p2.append("y"+str(j))

        v1 = xshift(p1)
        v2 = xshift(p2)
        e = []
        for j in range(np1):
            e.append([])
            f.write("\t\""+v1[j]+"\";\n")
            try:
                for k in range(random.randint(0, len(p2)-1)):
                    a = random.randint(0, len(p2)-1)
                    if a not in e[j]:
                        e[j].append(a)
            except:
                continue
            
        for j in range(np2):
            f.write("\t\""+v2[j]+"\";\n")
        f.write("\n")

        for j in range(np1):
            for k in range(len(e[j])):
                f.write("\t\""+v1[j]+"\" -- \""+v2[e[j][k]]+"\";\n")
        f.write("}\n")
        
        f.close()
        #if mix[i][1] < 64:
            #subprocess.call("dot -Tpng " + name+".dot" + " -o " + name+".png", shell=True)
